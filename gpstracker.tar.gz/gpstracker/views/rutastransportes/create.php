<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\RutasTransportes */

$this->title = 'Create Rutas Transportes';
$this->params['breadcrumbs'][] = ['label' => 'Rutas Transportes', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="rutas-transportes-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
