<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\RutasTransportes */

$this->title = 'Update Rutas Transportes: ' . $model->rtr_id;
$this->params['breadcrumbs'][] = ['label' => 'Rutas Transportes', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->rtr_id, 'url' => ['view', 'id' => $model->rtr_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="rutas-transportes-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
