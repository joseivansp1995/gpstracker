<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\RutasTransportes */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="rutas-transportes-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'rtr_fk_transporte')->textInput() ?>

    <?= $form->field($model, 'rtr_fk_ruta')->textInput() ?>

    <?= $form->field($model, 'rtr_fecha_inicio')->textInput() ?>

    <?= $form->field($model, 'trt_status')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
