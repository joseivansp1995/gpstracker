<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\RutasTransportesSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="rutas-transportes-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'data-pjax' => 1
        ],
    ]); ?>

    <?= $form->field($model, 'rtr_id') ?>

    <?= $form->field($model, 'rtr_fk_transporte') ?>

    <?= $form->field($model, 'rtr_fk_ruta') ?>

    <?= $form->field($model, 'rtr_fecha_inicio') ?>

    <?= $form->field($model, 'trt_status') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
