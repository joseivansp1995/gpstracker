<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ConductoresTransportesSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="conductores-transportes-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'data-pjax' => 1
        ],
    ]); ?>

    <?= $form->field($model, 'ctr_id') ?>

    <?= $form->field($model, 'ctr_fk_transporte') ?>

    <?= $form->field($model, 'ctr_fk_conductor') ?>

    <?= $form->field($model, 'ctr_fk_turno') ?>

    <?= $form->field($model, 'ctr_status') ?>

    <?php // echo $form->field($model, 'ctr_fecha') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
