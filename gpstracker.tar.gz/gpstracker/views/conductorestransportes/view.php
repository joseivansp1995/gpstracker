<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\ConductoresTransportes */

$this->title = $model->ctr_id;
$this->params['breadcrumbs'][] = ['label' => 'Conductores Transportes', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="conductores-transportes-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->ctr_id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->ctr_id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'ctr_id',
            'ctr_fk_transporte',
            'ctr_fk_conductor',
            'ctr_fk_turno',
            'ctr_status',
            'ctr_fecha',
        ],
    ]) ?>

</div>
