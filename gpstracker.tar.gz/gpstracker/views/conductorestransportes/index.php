<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\ConductoresTransportesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Conductores Transportes';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="conductores-transportes-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Conductores Transportes', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'ctr_id',
            'ctr_fk_transporte',
            'ctr_fk_conductor',
            'ctr_fk_turno',
            'ctr_status',
            //'ctr_fecha',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
