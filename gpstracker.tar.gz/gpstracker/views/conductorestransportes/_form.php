<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ConductoresTransportes */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="conductores-transportes-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'ctr_fk_transporte')->textInput() ?>

    <?= $form->field($model, 'ctr_fk_conductor')->textInput() ?>

    <?= $form->field($model, 'ctr_fk_turno')->textInput() ?>

    <?= $form->field($model, 'ctr_status')->textInput() ?>

    <?= $form->field($model, 'ctr_fecha')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
