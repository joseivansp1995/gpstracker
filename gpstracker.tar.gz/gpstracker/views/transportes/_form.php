<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Transportes */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="transportes-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'tra_nombre')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tra_placas')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tra_fk_equipo')->textInput() ?>

    <?= $form->field($model, 'tra_fk_usuario')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
