<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Gpslocalization */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="gpslocalization-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'gps_fk_equipo')->textInput() ?>

    <?= $form->field($model, 'gps_latitud')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'gps_longitud')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'gps_fecha_gps')->textInput() ?>

    <?= $form->field($model, 'gps_fecha_servidor')->textInput() ?>

    <?= $form->field($model, 'gps_hora_gps')->textInput() ?>

    <?= $form->field($model, 'gps_hora_servidor')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
