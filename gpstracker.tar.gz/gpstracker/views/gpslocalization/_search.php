<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\GpslocalizationSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="gpslocalization-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'data-pjax' => 1
        ],
    ]); ?>

    <?= $form->field($model, 'gps_id') ?>

    <?= $form->field($model, 'gps_fk_equipo') ?>

    <?= $form->field($model, 'gps_latitud') ?>

    <?= $form->field($model, 'gps_longitud') ?>

    <?= $form->field($model, 'gps_fecha_gps') ?>

    <?php // echo $form->field($model, 'gps_fecha_servidor') ?>

    <?php // echo $form->field($model, 'gps_hora_gps') ?>

    <?php // echo $form->field($model, 'gps_hora_servidor') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
