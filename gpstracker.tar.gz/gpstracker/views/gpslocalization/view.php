<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Gpslocalization */

$this->title = $model->gps_id;
$this->params['breadcrumbs'][] = ['label' => 'Gpslocalizations', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="gpslocalization-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->gps_id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->gps_id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'gps_id',
            'gps_fk_equipo',
            'gps_latitud',
            'gps_longitud',
            'gps_fecha_gps',
            'gps_fecha_servidor',
            'gps_hora_gps',
            'gps_hora_servidor',
        ],
    ]) ?>

</div>
