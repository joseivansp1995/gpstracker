<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Gpslocalization */

$this->title = 'Update Gpslocalization: ' . $model->gps_id;
$this->params['breadcrumbs'][] = ['label' => 'Gpslocalizations', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->gps_id, 'url' => ['view', 'id' => $model->gps_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="gpslocalization-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
