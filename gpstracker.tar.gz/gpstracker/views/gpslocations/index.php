<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\GpslocationsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Gpslocations';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="gpslocations-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Gpslocations', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'GPSLocationID',
            'lastUpdate',
            'latitude',
            'longitude',
            'phoneNumber',
            //'userName',
            //'sessionID',
            //'speed',
            //'direction',
            //'distance',
            //'gpsTime',
            //'locationMethod',
            //'accuracy',
            //'extraInfo',
            //'eventType',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
