<?php

namespace app\models;

/**
 * This is the ActiveQuery class for [[Gpslocations]].
 *
 * @see Gpslocations
 */
class GpslocationsQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * {@inheritdoc}
     * @return Gpslocations[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * {@inheritdoc}
     * @return Gpslocations|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
