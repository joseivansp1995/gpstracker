<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "conductores_transportes".
 *
 * @property int $ctr_id
 * @property int $ctr_fk_transporte
 * @property int $ctr_fk_conductor
 * @property int $ctr_fk_turno
 * @property int $ctr_status
 * @property string $ctr_fecha
 *
 * @property Transportes $ctrFkTransporte
 * @property Conductores $ctrFkConductor
 * @property Turnos $ctrFkTurno
 */
class ConductoresTransportes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'conductores_transportes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ctr_fk_transporte', 'ctr_fk_conductor', 'ctr_fk_turno', 'ctr_status'], 'integer'],
            [['ctr_fecha'], 'safe'],
            [['ctr_fk_transporte'], 'exist', 'skipOnError' => true, 'targetClass' => Transportes::className(), 'targetAttribute' => ['ctr_fk_transporte' => 'tra_id']],
            [['ctr_fk_conductor'], 'exist', 'skipOnError' => true, 'targetClass' => Conductores::className(), 'targetAttribute' => ['ctr_fk_conductor' => 'con_id']],
            [['ctr_fk_turno'], 'exist', 'skipOnError' => true, 'targetClass' => Turnos::className(), 'targetAttribute' => ['ctr_fk_turno' => 'tur_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ctr_id' => 'Ctr ID',
            'ctr_fk_transporte' => 'Ctr Fk Transporte',
            'ctr_fk_conductor' => 'Ctr Fk Conductor',
            'ctr_fk_turno' => 'Ctr Fk Turno',
            'ctr_status' => 'Ctr Status',
            'ctr_fecha' => 'Ctr Fecha',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCtrFkTransporte()
    {
        return $this->hasOne(Transportes::className(), ['tra_id' => 'ctr_fk_transporte']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCtrFkConductor()
    {
        return $this->hasOne(Conductores::className(), ['con_id' => 'ctr_fk_conductor']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCtrFkTurno()
    {
        return $this->hasOne(Turnos::className(), ['tur_id' => 'ctr_fk_turno']);
    }

    /**
     * {@inheritdoc}
     * @return ConductoresTransportesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new ConductoresTransportesQuery(get_called_class());
    }
}
