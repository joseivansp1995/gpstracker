<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ConductoresTransportes;

/**
 * ConductoresTransportesSearch represents the model behind the search form of `app\models\ConductoresTransportes`.
 */
class ConductoresTransportesSearch extends ConductoresTransportes
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ctr_id', 'ctr_fk_transporte', 'ctr_fk_conductor', 'ctr_fk_turno', 'ctr_status'], 'integer'],
            [['ctr_fecha'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = ConductoresTransportes::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'ctr_id' => $this->ctr_id,
            'ctr_fk_transporte' => $this->ctr_fk_transporte,
            'ctr_fk_conductor' => $this->ctr_fk_conductor,
            'ctr_fk_turno' => $this->ctr_fk_turno,
            'ctr_status' => $this->ctr_status,
            'ctr_fecha' => $this->ctr_fecha,
        ]);

        return $dataProvider;
    }
}
