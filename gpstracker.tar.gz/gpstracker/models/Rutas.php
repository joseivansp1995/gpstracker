<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "rutas".
 *
 * @property int $rut_id
 * @property int $rut_num_ruta
 * @property string $rut_nombre
 * @property string $rut_descripcion
 *
 * @property RutasTransportes[] $rutasTransportes
 */
class Rutas extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'rutas';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rut_num_ruta'], 'integer'],
            [['rut_nombre', 'rut_descripcion'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'rut_id' => 'Rut ID',
            'rut_num_ruta' => 'Rut Num Ruta',
            'rut_nombre' => 'Rut Nombre',
            'rut_descripcion' => 'Rut Descripcion',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRutasTransportes()
    {
        return $this->hasMany(RutasTransportes::className(), ['rtr_fk_ruta' => 'rut_id']);
    }

    /**
     * {@inheritdoc}
     * @return RutasQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new RutasQuery(get_called_class());
    }
}
