<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Rutas;

/**
 * RutasSearch represents the model behind the search form of `app\models\Rutas`.
 */
class RutasSearch extends Rutas
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rut_id', 'rut_num_ruta'], 'integer'],
            [['rut_nombre', 'rut_descripcion'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Rutas::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'rut_id' => $this->rut_id,
            'rut_num_ruta' => $this->rut_num_ruta,
        ]);

        $query->andFilterWhere(['like', 'rut_nombre', $this->rut_nombre])
            ->andFilterWhere(['like', 'rut_descripcion', $this->rut_descripcion]);

        return $dataProvider;
    }
}
