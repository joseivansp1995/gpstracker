<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "transportes".
 *
 * @property int $tra_id
 * @property string $tra_nombre
 * @property string $tra_placas
 * @property int $tra_fk_equipo
 * @property int $tra_fk_usuario
 *
 * @property Conductores[] $conductores
 * @property ConductoresTransportes[] $conductoresTransportes
 * @property RutasTransportes[] $rutasTransportes
 * @property Usuarios $traFkUsuario
 * @property Equipos $traFkEquipo
 */
class Transportes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'transportes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tra_fk_equipo', 'tra_fk_usuario'], 'integer'],
            [['tra_nombre', 'tra_placas'], 'string', 'max' => 255],
            [['tra_fk_usuario'], 'exist', 'skipOnError' => true, 'targetClass' => Usuarios::className(), 'targetAttribute' => ['tra_fk_usuario' => 'usu_id']],
            [['tra_fk_equipo'], 'exist', 'skipOnError' => true, 'targetClass' => Equipos::className(), 'targetAttribute' => ['tra_fk_equipo' => 'equ_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'tra_id' => 'Tra ID',
            'tra_nombre' => 'Tra Nombre',
            'tra_placas' => 'Tra Placas',
            'tra_fk_equipo' => 'Tra Fk Equipo',
            'tra_fk_usuario' => 'Tra Fk Usuario',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConductores()
    {
        return $this->hasMany(Conductores::className(), ['con_fk_transporte' => 'tra_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConductoresTransportes()
    {
        return $this->hasMany(ConductoresTransportes::className(), ['ctr_fk_transporte' => 'tra_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRutasTransportes()
    {
        return $this->hasMany(RutasTransportes::className(), ['rtr_fk_transporte' => 'tra_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTraFkUsuario()
    {
        return $this->hasOne(Usuarios::className(), ['usu_id' => 'tra_fk_usuario']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTraFkEquipo()
    {
        return $this->hasOne(Equipos::className(), ['equ_id' => 'tra_fk_equipo']);
    }

    /**
     * {@inheritdoc}
     * @return TransportesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new TransportesQuery(get_called_class());
    }
}
