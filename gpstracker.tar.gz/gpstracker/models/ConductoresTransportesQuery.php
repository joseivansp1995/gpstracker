<?php

namespace app\models;

/**
 * This is the ActiveQuery class for [[ConductoresTransportes]].
 *
 * @see ConductoresTransportes
 */
class ConductoresTransportesQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * {@inheritdoc}
     * @return ConductoresTransportes[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * {@inheritdoc}
     * @return ConductoresTransportes|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
