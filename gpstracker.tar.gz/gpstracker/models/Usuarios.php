<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "usuarios".
 *
 * @property int $usu_id
 * @property string $usu_usuario
 * @property string $usu_pass
 * @property string $usu_email
 * @property int $usu_fk_tipo_usuario
 *
 * @property Conductores[] $conductores
 * @property Equipos[] $equipos
 * @property Transportes[] $transportes
 * @property Tipousuario $usuFkTipoUsuario
 */
class Usuarios extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'usuarios';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['usu_fk_tipo_usuario'], 'integer'],
            [['usu_usuario', 'usu_pass', 'usu_email'], 'string', 'max' => 255],
            [['usu_fk_tipo_usuario'], 'exist', 'skipOnError' => true, 'targetClass' => Tipousuario::className(), 'targetAttribute' => ['usu_fk_tipo_usuario' => 'tip_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'usu_id' => 'Usu ID',
            'usu_usuario' => 'Usu Usuario',
            'usu_pass' => 'Usu Pass',
            'usu_email' => 'Usu Email',
            'usu_fk_tipo_usuario' => 'Usu Fk Tipo Usuario',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConductores()
    {
        return $this->hasMany(Conductores::className(), ['con_fk_usuario' => 'usu_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEquipos()
    {
        return $this->hasMany(Equipos::className(), ['equ_fk_usuario' => 'usu_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransportes()
    {
        return $this->hasMany(Transportes::className(), ['tra_fk_usuario' => 'usu_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuFkTipoUsuario()
    {
        return $this->hasOne(Tipousuario::className(), ['tip_id' => 'usu_fk_tipo_usuario']);
    }

    /**
     * {@inheritdoc}
     * @return UsuariosQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new UsuariosQuery(get_called_class());
    }
}
