<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Equipos;

/**
 * EquiposSearch represents the model behind the search form of `app\models\Equipos`.
 */
class EquiposSearch extends Equipos
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['equ_id', 'equ_telefono', 'equ_fk_usuario'], 'integer'],
            [['equ_nombre', 'equ_fecha_instalacion'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Equipos::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'equ_id' => $this->equ_id,
            'equ_fecha_instalacion' => $this->equ_fecha_instalacion,
            'equ_telefono' => $this->equ_telefono,
            'equ_fk_usuario' => $this->equ_fk_usuario,
        ]);

        $query->andFilterWhere(['like', 'equ_nombre', $this->equ_nombre]);

        return $dataProvider;
    }
}
