<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "turnos".
 *
 * @property int $tur_id
 * @property string $tur_descripcion
 *
 * @property Conductores[] $conductores
 * @property ConductoresTransportes[] $conductoresTransportes
 */
class Turnos extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'turnos';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tur_descripcion'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'tur_id' => 'Tur ID',
            'tur_descripcion' => 'Tur Descripcion',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConductores()
    {
        return $this->hasMany(Conductores::className(), ['con_fk_turno' => 'tur_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConductoresTransportes()
    {
        return $this->hasMany(ConductoresTransportes::className(), ['ctr_fk_turno' => 'tur_id']);
    }

    /**
     * {@inheritdoc}
     * @return TurnosQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new TurnosQuery(get_called_class());
    }
}
