<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Transportes;

/**
 * TransportesSearch represents the model behind the search form of `app\models\Transportes`.
 */
class TransportesSearch extends Transportes
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tra_id', 'tra_fk_equipo', 'tra_fk_usuario'], 'integer'],
            [['tra_nombre', 'tra_placas'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Transportes::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'tra_id' => $this->tra_id,
            'tra_fk_equipo' => $this->tra_fk_equipo,
            'tra_fk_usuario' => $this->tra_fk_usuario,
        ]);

        $query->andFilterWhere(['like', 'tra_nombre', $this->tra_nombre])
            ->andFilterWhere(['like', 'tra_placas', $this->tra_placas]);

        return $dataProvider;
    }
}
