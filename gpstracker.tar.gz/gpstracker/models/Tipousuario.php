<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "tipousuario".
 *
 * @property int $tip_id
 * @property string $tip_descripcion
 *
 * @property Usuarios[] $usuarios
 */
class Tipousuario extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tipousuario';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tip_descripcion'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'tip_id' => 'Tip ID',
            'tip_descripcion' => 'Tip Descripcion',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios()
    {
        return $this->hasMany(Usuarios::className(), ['usu_fk_tipo_usuario' => 'tip_id']);
    }

    /**
     * {@inheritdoc}
     * @return TipousuarioQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new TipousuarioQuery(get_called_class());
    }
}
