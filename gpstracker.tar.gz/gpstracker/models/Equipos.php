<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "equipos".
 *
 * @property int $equ_id
 * @property string $equ_nombre
 * @property string $equ_fecha_instalacion
 * @property int $equ_telefono
 * @property int $equ_fk_usuario
 *
 * @property Usuarios $equFkUsuario
 * @property Gpslocalization[] $gpslocalizations
 * @property Transportes[] $transportes
 */
class Equipos extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'equipos';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['equ_fecha_instalacion'], 'safe'],
            [['equ_telefono', 'equ_fk_usuario'], 'integer'],
            [['equ_nombre'], 'string', 'max' => 255],
            [['equ_fk_usuario'], 'exist', 'skipOnError' => true, 'targetClass' => Usuarios::className(), 'targetAttribute' => ['equ_fk_usuario' => 'usu_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'equ_id' => 'Equ ID',
            'equ_nombre' => 'Equ Nombre',
            'equ_fecha_instalacion' => 'Equ Fecha Instalacion',
            'equ_telefono' => 'Equ Telefono',
            'equ_fk_usuario' => 'Equ Fk Usuario',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEquFkUsuario()
    {
        return $this->hasOne(Usuarios::className(), ['usu_id' => 'equ_fk_usuario']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGpslocalizations()
    {
        return $this->hasMany(Gpslocalization::className(), ['gps_fk_equipo' => 'equ_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransportes()
    {
        return $this->hasMany(Transportes::className(), ['tra_fk_equipo' => 'equ_id']);
    }

    /**
     * {@inheritdoc}
     * @return EquiposQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new EquiposQuery(get_called_class());
    }
}
