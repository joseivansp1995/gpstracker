<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "gpslocalization".
 *
 * @property int $gps_id
 * @property int $gps_fk_equipo
 * @property string $gps_latitud
 * @property string $gps_longitud
 * @property string $gps_fecha_gps
 * @property string $gps_fecha_servidor
 * @property string $gps_hora_gps
 * @property string $gps_hora_servidor
 *
 * @property Equipos $gpsFkEquipo
 */
class Gpslocalization extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'gpslocalization';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['gps_fk_equipo'], 'integer'],
            [['gps_fecha_gps', 'gps_fecha_servidor', 'gps_hora_gps', 'gps_hora_servidor'], 'safe'],
            [['gps_latitud', 'gps_longitud'], 'string', 'max' => 255],
            [['gps_fk_equipo'], 'exist', 'skipOnError' => true, 'targetClass' => Equipos::className(), 'targetAttribute' => ['gps_fk_equipo' => 'equ_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'gps_id' => 'Gps ID',
            'gps_fk_equipo' => 'Gps Fk Equipo',
            'gps_latitud' => 'Gps Latitud',
            'gps_longitud' => 'Gps Longitud',
            'gps_fecha_gps' => 'Gps Fecha Gps',
            'gps_fecha_servidor' => 'Gps Fecha Servidor',
            'gps_hora_gps' => 'Gps Hora Gps',
            'gps_hora_servidor' => 'Gps Hora Servidor',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGpsFkEquipo()
    {
        return $this->hasOne(Equipos::className(), ['equ_id' => 'gps_fk_equipo']);
    }

    /**
     * {@inheritdoc}
     * @return GpslocalizationQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new GpslocalizationQuery(get_called_class());
    }
}
