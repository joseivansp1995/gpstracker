<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Gpslocalization;

/**
 * GpslocalizationSearch represents the model behind the search form of `app\models\Gpslocalization`.
 */
class GpslocalizationSearch extends Gpslocalization
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['gps_id', 'gps_fk_equipo'], 'integer'],
            [['gps_latitud', 'gps_longitud', 'gps_fecha_gps', 'gps_fecha_servidor', 'gps_hora_gps', 'gps_hora_servidor'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Gpslocalization::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'gps_id' => $this->gps_id,
            'gps_fk_equipo' => $this->gps_fk_equipo,
            'gps_fecha_gps' => $this->gps_fecha_gps,
            'gps_fecha_servidor' => $this->gps_fecha_servidor,
            'gps_hora_gps' => $this->gps_hora_gps,
            'gps_hora_servidor' => $this->gps_hora_servidor,
        ]);

        $query->andFilterWhere(['like', 'gps_latitud', $this->gps_latitud])
            ->andFilterWhere(['like', 'gps_longitud', $this->gps_longitud]);

        return $dataProvider;
    }
}
