<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "conductores".
 *
 * @property int $con_id
 * @property string $con_nombre
 * @property int $con_fk_transporte
 * @property int $con_fk_usuario
 * @property int $con_fk_turno
 *
 * @property Transportes $conFkTransporte
 * @property Usuarios $conFkUsuario
 * @property Turnos $conFkTurno
 * @property ConductoresTransportes[] $conductoresTransportes
 */
class Conductores extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'conductores';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['con_fk_transporte', 'con_fk_usuario', 'con_fk_turno'], 'integer'],
            [['con_nombre'], 'string', 'max' => 255],
            [['con_fk_transporte'], 'exist', 'skipOnError' => true, 'targetClass' => Transportes::className(), 'targetAttribute' => ['con_fk_transporte' => 'tra_id']],
            [['con_fk_usuario'], 'exist', 'skipOnError' => true, 'targetClass' => Usuarios::className(), 'targetAttribute' => ['con_fk_usuario' => 'usu_id']],
            [['con_fk_turno'], 'exist', 'skipOnError' => true, 'targetClass' => Turnos::className(), 'targetAttribute' => ['con_fk_turno' => 'tur_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'con_id' => 'Con ID',
            'con_nombre' => 'Con Nombre',
            'con_fk_transporte' => 'Con Fk Transporte',
            'con_fk_usuario' => 'Con Fk Usuario',
            'con_fk_turno' => 'Con Fk Turno',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConFkTransporte()
    {
        return $this->hasOne(Transportes::className(), ['tra_id' => 'con_fk_transporte']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConFkUsuario()
    {
        return $this->hasOne(Usuarios::className(), ['usu_id' => 'con_fk_usuario']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConFkTurno()
    {
        return $this->hasOne(Turnos::className(), ['tur_id' => 'con_fk_turno']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConductoresTransportes()
    {
        return $this->hasMany(ConductoresTransportes::className(), ['ctr_fk_conductor' => 'con_id']);
    }

    /**
     * {@inheritdoc}
     * @return ConductoresQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new ConductoresQuery(get_called_class());
    }
}
