<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\RutasTransportes;

/**
 * RutasTransportesSearch represents the model behind the search form of `app\models\RutasTransportes`.
 */
class RutasTransportesSearch extends RutasTransportes
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rtr_id', 'rtr_fk_transporte', 'rtr_fk_ruta', 'trt_status'], 'integer'],
            [['rtr_fecha_inicio'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = RutasTransportes::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'rtr_id' => $this->rtr_id,
            'rtr_fk_transporte' => $this->rtr_fk_transporte,
            'rtr_fk_ruta' => $this->rtr_fk_ruta,
            'rtr_fecha_inicio' => $this->rtr_fecha_inicio,
            'trt_status' => $this->trt_status,
        ]);

        return $dataProvider;
    }
}
