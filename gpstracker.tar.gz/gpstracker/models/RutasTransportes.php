<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "rutas_transportes".
 *
 * @property int $rtr_id
 * @property int $rtr_fk_transporte
 * @property int $rtr_fk_ruta
 * @property string $rtr_fecha_inicio
 * @property int $trt_status
 *
 * @property Transportes $rtrFkTransporte
 * @property Rutas $rtrFkRuta
 */
class RutasTransportes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'rutas_transportes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rtr_fk_transporte', 'rtr_fk_ruta', 'trt_status'], 'integer'],
            [['rtr_fecha_inicio'], 'safe'],
            [['rtr_fk_transporte'], 'exist', 'skipOnError' => true, 'targetClass' => Transportes::className(), 'targetAttribute' => ['rtr_fk_transporte' => 'tra_id']],
            [['rtr_fk_ruta'], 'exist', 'skipOnError' => true, 'targetClass' => Rutas::className(), 'targetAttribute' => ['rtr_fk_ruta' => 'rut_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'rtr_id' => 'Rtr ID',
            'rtr_fk_transporte' => 'Rtr Fk Transporte',
            'rtr_fk_ruta' => 'Rtr Fk Ruta',
            'rtr_fecha_inicio' => 'Rtr Fecha Inicio',
            'trt_status' => 'Trt Status',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRtrFkTransporte()
    {
        return $this->hasOne(Transportes::className(), ['tra_id' => 'rtr_fk_transporte']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRtrFkRuta()
    {
        return $this->hasOne(Rutas::className(), ['rut_id' => 'rtr_fk_ruta']);
    }

    /**
     * {@inheritdoc}
     * @return RutasTransportesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new RutasTransportesQuery(get_called_class());
    }
}
